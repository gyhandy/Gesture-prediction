# -*- coding: utf-8 -*-
import time
import csv
import pandas as pd
import numpy as np
import serial

ser = serial.Serial( #下面这些参数根据情况修改
    port='COM3',
    baudrate=38400,
    parity=serial.PARITY_ODD,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS
)

data = []
iterate = 30
index = 0
c = []
time.sleep(0.01)
while iterate:
    time.sleep(0.01)
    while ser.inWaiting() > 0:
        try:
            a = str(ser.readline()).strip()
            b = a.split(',')
            assert len(b) == 6
            c.append(b[0])
            c.append(b[1])
            c.append(b[2])
            c.append(b[3])
            c.append(b[4])
            c.append(b[5])
            data.append(c)
            # i_data = c
            print(c)
            c = []
            # data.append(i_data)
        except AssertionError:
            print('AssertionError')
        except:
            print('error')

    iterate -= 1
print(iterate)
print(ser.inWaiting())
csvFile2 = open('test.csv', 'w') # 设置newline，否则两行之间会空一行, newline=''
writer = csv.writer(csvFile2)
m = len(data)
for i in range(m):
    writer.writerow(data[i])
csvFile2.close()


