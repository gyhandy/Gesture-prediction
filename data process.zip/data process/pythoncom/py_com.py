import time
import csv
import pandas as pd
import numpy as np
import serial

ser = serial.Serial( #下面这些参数根据情况修改
    port='COM3',
    baudrate=9600,
    parity=serial.PARITY_ODD,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS
)

data = []
time.sleep(0.5)
iterate = 20
c = []
for i in range(iterate):
    time.sleep(0.3)
    while ser.inWaiting() > 0:
        try:
            # a = str(ser.readline()).strip()#保证
            c.append(round(float(b[3])))
            b = a.split(',')
            c.append(round(float(b[0][2:])))
            c.append(round(float(b[1])))
            c.append(round(float(b[2])))
            c.append(round(float(b[3])))
            c.append(round(float(b[4])))
            c.append(round(float(b[5][:-5])))
            i_data=c
            c = []
            if i_data != []:
                print(i_data)
            data.append(i_data)
            i += 1
        except:
            break

#print(data)



csvFile2 = open('test.csv','w', newline='') # 设置newline，否则两行之间会空一行
writer = csv.writer(csvFile2)
m = len(data)
for i in range(m):
    writer.writerow(data[i])
csvFile2.close()


