# -*- coding:utf-8 -*-
import time
import numpy as np
import serial
import tensorflow as tf
import h5py

file = h5py.File('MutiLayerPercetron_model.h5', 'r')

scaler_data_max = file['scaler_data_max']
scaler_data_min = file['scaler_data_min']
scaler_data_scaler = file['scaler_data_scaler']

x_data = tf.placeholder(shape=[None, 10], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, 6], dtype=tf.float32)

def fully_connected(input_layer, weights, biases):
    layer = tf.add(tf.matmul(input_layer, weights), biases)
    return(tf.nn.relu(layer))

def print_once(dict, new_state, pre_state):
    if new_state != pre_state:
        print(dict[newstate])

# create hidden layer
weight_1 = file['weight_1'][:]
bias_1 = file['bias_1'][:]
layer_1 = fully_connected(x_data, weight_1, bias_1)

weight_2 = file['weight_2'][:]
bias_2 = file['bias_2'][:]
layer_2 = fully_connected(layer_1, weight_2, bias_2)

weight_3 = file['weight_3'][:]
bias_3 = file['bias_3'][:]
layer_3 = fully_connected(layer_2, weight_3, bias_3)

# create output layer
weight_4 = file['weight_4'][:]
bias_4 = file['bias_4'][:]
final_output = tf.matmul(layer_3, weight_4) + bias_4

predict = tf.argmax(final_output, 1)

# Create a Session
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)
# ok-0  rock-1  sissor-2  4-3  6-4  8-5
gesturedict = {0: 'ok', 1: 'rock', 2: 'sissor', 3: '4', 4: '6', 5: '8'}

data = np.zeros([17, 15])
num_data = 0
index = 0
n = 5  # number of data to define the gesture

ser = serial.Serial( #下面这些参数根据情况修改
    port='/dev/ttyACM1',
    baudrate=9600,
    parity=serial.PARITY_ODD,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS
)

time.sleep(0.5)
steady_state = np.zeros((25,1)); steady_state_index = 0; prestate = 0
keepstate = np.zeros((2,1));stateindex = 0;switch_flag = 0;tmp_output = 0;tmp_flag = 0
while True:
    while ser.inWaiting() > 0:
        try:
            a = str(ser.readline()).strip()
            b = a.split(',')
            assert len(b) == 5
            data[index, 0] = b[0]
            data[index, 1] = b[1]
            data[index, 2] = b[2]
            data[index, 3] = b[3]
            data[index, 4] = b[4]
            # print(a)
            if num_data >= 6:
                cur_index = num_data % 17
                data[cur_index - 3][5] = data[cur_index][0] - data[cur_index - 6][0]
                data[cur_index - 3][7] = data[cur_index][1] - data[cur_index - 6][1]
                data[cur_index - 3][9] = data[cur_index][2] - data[cur_index - 6][2]
                data[cur_index - 3][11] = data[cur_index][3] - data[cur_index - 6][3]
                data[cur_index - 3][13] = data[cur_index][4] - data[cur_index - 6][4]
                # data[index - 3][5] = data[index][0] - data[index - 6][0]
                # data[index - 3][7] = data[index][1] - data[index - 6][1]
                # data[index - 3][9] = data[index][2] - data[index - 6][2]
                # data[index - 3][11] = data[index][3] - data[index - 6][3]
                # data[index - 3][13] = data[index][4] - data[index - 6][4]

            if num_data >= 16:
                cur_index = num_data % 17
                if cur_index - 8 - 5 >= -11 and cur_index - 8 - 5 <= -1:
                    matrix = np.concatenate((data[cur_index - 8 - 5:, :], data[:cur_index - 8 + 5 + 1, :]))
                    data[cur_index - 8][6] = np.sum(matrix[:, 5]) / 11.0
                    data[cur_index - 8][8] = np.sum(matrix[:, 7]) / 11.0
                    data[cur_index - 8][10] = np.sum(matrix[:, 9]) / 11.0
                    data[cur_index - 8][12] = np.sum(matrix[:, 11]) / 11.0
                    data[cur_index - 8][14] = np.sum(matrix[:, 13]) / 11.0
                else:
                    matrix = data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, :]
                    data[cur_index - 8][6] = np.sum(matrix[:, 5]) / 11.0
                    data[cur_index - 8][8] = np.sum(matrix[:, 7]) / 11.0
                    data[cur_index - 8][10] = np.sum(matrix[:, 9]) / 11.0
                    data[cur_index - 8][12] = np.sum(matrix[:, 11]) / 11.0
                    data[cur_index - 8][14] = np.sum(matrix[:, 13]) / 11.0
                    # data[cur_index - 8][6] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 5]) / 11.0
                    # data[cur_index - 8][8] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 7]) / 11.0
                    # data[cur_index - 8][10] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 9]) / 11.0
                    # data[cur_index - 8][12] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 11]) / 11.0
                    # data[cur_index - 8][14] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 13]) / 11.0

            # detect the gesture every n samples
            if num_data >= 20:
                cur_index = (num_data - 20 + 8) % 17
                col = np.array([0, 1, 2, 3, 4, 6, 8, 10, 12, 14])
                if cur_index + n > 17:
                    # input_MutiLayer = 1
                    new_index = (cur_index + n) % 16
                    input_MutiLayer = np.concatenate((data[cur_index:, col], data[:new_index - 1, col]))
                else:
                    input_MutiLayer = data[cur_index:cur_index + n, col]

                # detect the input
                # scale
                input_MutiLayer = (input_MutiLayer - scaler_data_min) * scaler_data_scaler
                Gesture_kind = sess.run(predict, feed_dict={x_data: input_MutiLayer})

                tu = sorted([(np.sum(Gesture_kind == i), i) for i in set(Gesture_kind.flat)])
                output = tu[-1][1]

                ###########################################################
                # if tmp_output == output and tmp_flag == 0:
                #     s_time = time.time()
                #     tmp_flag = 1
                # if tmp_flag == 1:
                #     if tmp_output == output:
                #         if time.time() - s_time > 0.05:
                #             tmp_flag = 0
                #             # print(output)
                #             keepstate[stateindex] = output
                #             stateindex = (stateindex + 1) % 2
                #     else:
                #         tmp_output = output
                #
                # if keepstate[0] != keepstate[1]:
                #     time_start = time.time()
                #     switch_flag = 1
                # if switch_flag == 1:
                #     if keepstate[0] == keepstate[1]:
                #         time_end = time.time()
                #         if time_end - time_start > 0.1:
                #             print(gesturedict[output])
                #             switch_flag = 0
                # tmp_output = output
                #
                #####################################################
                # steady_state[steady_state_index] = output
                # uu = sorted([(np.sum(steady_state == i), i) for i in set(steady_state.flat)])
                # if uu[-1][0] >= 0.9 * steady_state.shape[0]:
                #     newstate = int(uu[-1][1])
                #
                #     print_once(gesturedict, newstate, prestate)
                #     prestate = newstate
                #     # print(gesturedict[newstate])
                #
                # steady_state_index = (steady_state_index + 1) % steady_state.shape[0]

                #####################################################
                keepstate[stateindex] = output
                if keepstate[0] != keepstate[1]:
                    time_start = time.time()
                    switch_flag = 1
                if switch_flag == 1:
                    if keepstate[0] == keepstate[1]:
                        time_end = time.time()
                        if time_end - time_start > 0.2:
                            print(gesturedict[output])
                            switch_flag = 0

                print(str(Gesture_kind)+'   '+str(output)+'   ' + gesturedict[output])
                # print(gesturedict[output])
                ####################################################

            index = (index + 1) % 17
            # stateindex = (stateindex + 1) % 2
            num_data += 1
        except AssertionError:
            print('AssertionError')
        except ValueError:
            print('ValueError')

