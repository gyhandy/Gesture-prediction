#!/bin/bash
set -e

python merge_allcsv.py
