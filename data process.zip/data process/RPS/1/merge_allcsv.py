import numpy as np
import os
import glob
import csv

files = glob.glob('./*.csv')
output = []
for f in files:
    output.append(np.genfromtxt(f, dtype=np.float, delimiter=",").tolist())

csvFile2 = open('test.csv', 'w')
writer = csv.writer(csvFile2)
m = len(output)
for i in range(m):
    for j in range(len(output[i])):
        writer.writerow(output[i][j])
csvFile2.close()
print('Finished')
