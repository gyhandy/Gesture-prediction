#-*- coding= utf-8 -*-


import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.externals import joblib


# Load the data

g_data_r = np.genfromtxt("rock.csv", dtype=np.float, delimiter=",")
g_data_s = np.genfromtxt("sissor.csv", dtype=np.float, delimiter=",")
g_data_o = np.genfromtxt("ok.csv", dtype=np.float, delimiter=",")
g_data_4 = np.genfromtxt("4.csv", dtype=np.float, delimiter=",")
g_data_6 = np.genfromtxt("6.csv", dtype=np.float, delimiter=",")
g_data_8 = np.genfromtxt("8.csv", dtype=np.float, delimiter=",")
g_data = np.append(g_data_r[1:, :], g_data_s[1:, :], axis=0)
g_data = np.append(g_data, g_data_o[1:, :], axis=0)
g_data = np.append(g_data, g_data_4[1:, :], axis=0)
g_data = np.append(g_data, g_data_6[1:, :], axis=0)
g_data = np.append(g_data, g_data_8[1:, :], axis=0)


# create arrays for labels
g_label_r = np.tile([0], (g_data_r.shape[0]-1, 1)) # 0:r
g_label_s = np.tile([1], (g_data_s.shape[0]-1, 1)) # 1:s
g_label_o = np.tile([2], (g_data_o.shape[0]-1, 1)) # 2:o
g_label_4 = np.tile([3], (g_data_4.shape[0]-1, 1)) # 3:四
g_label_6 = np.tile([4], (g_data_6.shape[0]-1, 1)) # 4:六
g_label_8 = np.tile([5], (g_data_8.shape[0]-1, 1)) # 5:八
g_label = np.append(g_label_r, g_label_s, axis=0)
g_label = np.append(g_label, g_label_o, axis=0)
g_label = np.append(g_label, g_label_4, axis=0)
g_label = np.append(g_label, g_label_6, axis=0)
g_label = np.append(g_label, g_label_8, axis=0)

# training and testing dataset
train_indices = np.random.choice(len(g_data),
                                 round(len(g_data)*0.8),
                                 replace=False)
test_indices = np.array(list(set(range(len(g_data))) - set(train_indices)))
traindata = g_data[train_indices]
trainlabel = g_label[train_indices]
testdata = g_data[test_indices]
testlabel = g_label[test_indices]

# linear kernal
# polynomial_svm_clf =Pipeline((
#     ("poly_features", PolynomialFeatures(degree=3)),
#     ("scaler",StandardScaler()),
#     ("svm_clf", LinearSVC(C=10,loss="hinge"))
# ))

# polynomial_svm_clf.fit(X, y)



# Gaussian RBF ovr
rbf_kernal_ovr = Pipeline((
    ("scaler", StandardScaler()),
    ("rbf_ovr", SVC(kernel="rbf",  decision_function_shape='ovr')),
))
rbf_kernal_ovr.fit(traindata, trainlabel)
# Gaussian RBF ovo
rbf_kernal_ovo = Pipeline((
    ("scaler", StandardScaler()),
    ("rbf_ovo", SVC(kernel="rbf",  decision_function_shape='ovo')),
))
rbf_kernal_ovo.fit(traindata, trainlabel)
# Poly ovr
ploy_kernal_ovr = Pipeline((
    ("scaler", StandardScaler()),
    ("poly_ovr", SVC(kernel="poly", decision_function_shape='ovr')),
))
ploy_kernal_ovr.fit(traindata, trainlabel)
# Poly ovo
ploy_kernal_ovo = Pipeline((
    ("scaler", StandardScaler()),
    ("poly_ovo", SVC(kernel="poly", decision_function_shape='ovo')),
))
ploy_kernal_ovo.fit(traindata, trainlabel)


# prediction & accuracy
def make_prediction( pred_model ):
    prediction = pred_model.predict(testdata)
    sum_value = 0
    for i in range(len(prediction)):
        a = 1 if prediction[i] == testlabel[i] else 0
        sum_value += a
    accuracy = float(sum_value) / float(len(prediction))
    return (accuracy)

accuracy_Guass_rbf_ovr = make_prediction(rbf_kernal_ovr)
accuracy_Guass_rbf_ovo = make_prediction(rbf_kernal_ovo)
accuracy_Poly_ovr = make_prediction(ploy_kernal_ovr)
accuracy_Poly_ovo = make_prediction(ploy_kernal_ovo)

print("The Guassian RBF kernal in one verse all accuracy is {0}".format(accuracy_Guass_rbf_ovr))
print("The Guassian RBF kernal in one verse one accuracy is {0}".format(accuracy_Guass_rbf_ovo))
print("The Polynomial kernal in one verse all accuracy is {0}".format(accuracy_Poly_ovr))
print("The Polynomial kernal in one verse one accuracy is {0}".format(accuracy_Poly_ovo))



# model save
joblib.dump(rbf_kernal_ovr, 'rbf_kernal_ovr.pkl')
rbf_kernal_ovr_save = joblib.load('rbf_kernal_ovr.pkl')
accuracy_Guass_rbf_ovr_save = make_prediction(rbf_kernal_ovr_save)
print("The Guassian RBF kernal in one verse all accuracy is {0}".format(accuracy_Guass_rbf_ovr_save))
