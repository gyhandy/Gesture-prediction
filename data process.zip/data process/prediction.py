import numpy as np
import tensorflow as tf
import h5py
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.externals import joblib
import time

start = time.time()

rbf_kernal_ovr_save = joblib.load('rbf_kernal_ovr.pkl')

input = np.genfromtxt("si1.csv", dtype=np.float, delimiter=",")[1:][:]
datainput = input[0:1000][:]
data=np.zeros([17,15])
num_data = 0
index = 0
n = 5 # number of data to define the gesture
for num in range(datainput.shape[0]):
    data[index][0] = datainput[num][0]
    data[index][1] = datainput[num][1]
    data[index][2] = datainput[num][2]
    data[index][3] = datainput[num][3]
    data[index][4] = datainput[num][4]
    if num_data >= 6:
        cur_index = num_data % 17
        data[cur_index - 3][5] = data[cur_index][0] - data[cur_index - 6][0]
        data[cur_index - 3][7] = data[cur_index][1] - data[cur_index - 6][1]
        data[cur_index - 3][9] = data[cur_index][2] - data[cur_index - 6][2]
        data[cur_index - 3][11] = data[cur_index][3] - data[cur_index - 6][3]
        data[cur_index - 3][13] = data[cur_index][4] - data[cur_index - 6][4]
        # data[index - 3][5] = data[index][0] - data[index - 6][0]
        # data[index - 3][7] = data[index][1] - data[index - 6][1]
        # data[index - 3][9] = data[index][2] - data[index - 6][2]
        # data[index - 3][11] = data[index][3] - data[index - 6][3]
        # data[index - 3][13] = data[index][4] - data[index - 6][4]

    if num_data >= 16:
        cur_index = num_data % 17
        if cur_index - 8 - 5 >= -11 and cur_index - 8 - 5 <= -1:
            matrix = np.concatenate((data[cur_index - 8 - 5:, :], data[:cur_index - 8 + 5 + 1, :]))
            data[cur_index - 8][6] = np.sum(matrix[:,5]) / 11.0
            data[cur_index - 8][8] = np.sum(matrix[:,7]) / 11.0
            data[cur_index - 8][10] = np.sum(matrix[:,9]) / 11.0
            data[cur_index - 8][12] = np.sum(matrix[:,11]) / 11.0
            data[cur_index - 8][14] = np.sum(matrix[:,13]) / 11.0
        else:
            matrix = data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, :]
            data[cur_index - 8][6] = np.sum(matrix[:,5]) / 11.0
            data[cur_index - 8][8] = np.sum(matrix[:,7]) / 11.0
            data[cur_index - 8][10] = np.sum(matrix[:,9]) / 11.0
            data[cur_index - 8][12] = np.sum(matrix[:,11]) / 11.0
            data[cur_index - 8][14] = np.sum(matrix[:,13]) / 11.0
            # data[cur_index - 8][6] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 5]) / 11.0
            # data[cur_index - 8][8] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 7]) / 11.0
            # data[cur_index - 8][10] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 9]) / 11.0
            # data[cur_index - 8][12] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 11]) / 11.0
            # data[cur_index - 8][14] = np.sum(data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, 13]) / 11.0

    # detect the gesture every n samples
    if num_data >= 20:
        cur_index = (num_data - 20 + 8) % 17
        col =np.array([0, 1, 2, 3, 4, 6, 8, 10, 12, 14])
        if cur_index+n > 17:
            # input_MutiLayer = 1
            new_index = (cur_index + n)%16
            input_MutiLayer = np.concatenate((data[cur_index:, col], data[:new_index-1, col]))
        else:
            input_MutiLayer = data[cur_index:cur_index+n, col]

        # detect the input
        # scale



        # Gesture_kind = sess.run(predict, feed_dict={x_data: input_MutiLayer})
        Gesture_kind = rbf_kernal_ovr_save.predict(input_MutiLayer)



        print(Gesture_kind)




    index = (index + 1) % 17
    num_data += 1
print(time.time()-start)