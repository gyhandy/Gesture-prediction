s = serial('COM3');
set(s,'BaudRate',9600);
%fclose(s)
fopen(s);

interval = 100;
passo = 1;
t = 1;
x = 0;
while(t<interval)
    b = str2num(fgetl(s));
    x = [x,b];
    plot(x);
    grid;
    t = t + passo;
    drawnow;
end
%csvwrite('a.csv',x)
fclose(s)