#-*- coding= utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.externals import joblib

# Load the data

g_data_8 = np.genfromtxt("./data/feature8.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_like = np.genfromtxt("./data/featurelike.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_ok = np.genfromtxt("./data/featureok.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_rock = np.genfromtxt("./data/featurerock.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_scissor = np.genfromtxt("./data/featurescissor.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_start = np.genfromtxt("./data/featurestart.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_thumb = np.genfromtxt("./data/featurethumb.csv", dtype=np.float, delimiter=",")[1:][:]


# merge all to g_data
g_data = np.append(g_data_8, g_data_like, axis=0)
g_data = np.append(g_data, g_data_ok, axis=0)
g_data = np.append(g_data, g_data_rock, axis=0)
g_data = np.append(g_data, g_data_scissor, axis=0)
g_data = np.append(g_data, g_data_start, axis=0)
g_data = np.append(g_data, g_data_thumb, axis=0)

# select features
############## Single Finger ###################
# # P
# col = np.array([0, 1, 2, 3, 4])
# # PV
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15])
# # PVA
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 18, 19, 20, 21, 22, 23])

############## Adjacent Finger ###################
# # P
# col = np.array([0, 1, 2, 3, 4, 24, 25, 26, 27])
# # PV
col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 24, 25, 26, 27, 28, 29, 30, 31])
# # PVA
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])

g_data = g_data[:, col]

# create arrays for labels
g_label_8 = np.tile([0], (g_data_8.shape[0], 1)) # 0:r
g_label_like = np.tile([1], (g_data_like.shape[0], 1)) # 1:s
g_label_ok = np.tile([2], (g_data_ok.shape[0], 1)) # 2:o
g_label_rock = np.tile([3], (g_data_rock.shape[0], 1)) # 3:四
g_label_scissor = np.tile([4], (g_data_scissor.shape[0], 1)) # 4:六
g_label_start = np.tile([5], (g_data_start.shape[0], 1)) # 5:八
g_label_thumb = np.tile([5], (g_data_thumb.shape[0], 1)) # 5:八

g_label = np.append(g_label_8, g_label_like, axis=0)
g_label = np.append(g_label, g_label_ok, axis=0)
g_label = np.append(g_label, g_label_rock, axis=0)
g_label = np.append(g_label, g_label_scissor, axis=0)
g_label = np.append(g_label, g_label_start, axis=0)
g_label = np.append(g_label, g_label_thumb, axis=0)

# training and testing dataset
train_indices = np.random.choice(len(g_data),
                                 int(len(g_data)*0.8),
                                 replace=False)
test_indices = np.array(list(set(range(len(g_data))) - set(train_indices)))
traindata = g_data[train_indices]
trainlabel = g_label[train_indices]
testdata = g_data[test_indices]
testlabel = g_label[test_indices]

# linear kernal
# polynomial_svm_clf =Pipeline((
#     ("poly_features", PolynomialFeatures(degree=3)),
#     ("scaler",StandardScaler()),
#     ("svm_clf", LinearSVC(C=10,loss="hinge"))
# ))

# polynomial_svm_clf.fit(X, y)

# Gaussian RBF ovr
rbf_kernal_ovr = Pipeline((
    ("scaler", StandardScaler()),
    ("rbf_ovr", SVC(kernel="rbf",  decision_function_shape='ovr')),
))
rbf_kernal_ovr.fit(traindata, trainlabel)
# Gaussian RBF ovo
rbf_kernal_ovo = Pipeline((
    ("scaler", StandardScaler()),
    ("rbf_ovo", SVC(kernel="rbf",  decision_function_shape='ovo')),
))
rbf_kernal_ovo.fit(traindata, trainlabel)
# Poly ovr
ploy_kernal_ovr = Pipeline((
    ("scaler", StandardScaler()),
    ("poly_ovr", SVC(kernel="poly", decision_function_shape='ovr')),
))
ploy_kernal_ovr.fit(traindata, trainlabel)
# Poly ovo
ploy_kernal_ovo = Pipeline((
    ("scaler", StandardScaler()),
    ("poly_ovo", SVC(kernel="poly", decision_function_shape='ovo')),
))
ploy_kernal_ovo.fit(traindata, trainlabel)

# prediction & accuracy
def make_prediction(pred_model):
    prediction = pred_model.predict(testdata)
    sum_value = 0
    for i in range(len(prediction)):
        a = 1 if prediction[i] == testlabel[i] else 0
        sum_value += a
    accuracy = float(sum_value) / float(len(prediction))
    return (accuracy)

accuracy_Guass_rbf_ovr = make_prediction(rbf_kernal_ovr)
accuracy_Guass_rbf_ovo = make_prediction(rbf_kernal_ovo)
accuracy_Poly_ovr = make_prediction(ploy_kernal_ovr)
accuracy_Poly_ovo = make_prediction(ploy_kernal_ovo)

print("The Guassian RBF kernal in one verse all accuracy is {0}".format(accuracy_Guass_rbf_ovr))
print("The Guassian RBF kernal in one verse one accuracy is {0}".format(accuracy_Guass_rbf_ovo))
print("The Polynomial kernal in one verse all accuracy is {0}".format(accuracy_Poly_ovr))
print("The Polynomial kernal in one verse one accuracy is {0}".format(accuracy_Poly_ovo))

# model save
joblib.dump(rbf_kernal_ovr, 'rbf_kernal_ovr.pkl')
joblib.dump(rbf_kernal_ovo, 'rbf_kernal_ovo.pkl')
joblib.dump(ploy_kernal_ovr, 'ploy_kernal_ovr.pkl')
joblib.dump(ploy_kernal_ovo, 'ploy_kernal_ovo.pkl')
# rbf_kernal_ovr_save = joblib.load('rbf_kernal_ovr.pkl')
# accuracy_Guass_rbf_ovr_save = make_prediction(rbf_kernal_ovr_save)
# print("The Guassian RBF kernal in one verse all accuracy is {0}".format(accuracy_Guass_rbf_ovr_save))
