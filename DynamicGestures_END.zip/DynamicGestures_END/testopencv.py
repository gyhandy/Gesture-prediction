import cv2

img = cv2.imread('like.png', cv2.IMREAD_ANYCOLOR)
cv2.imshow('lala', img)
cv2.waitKey(1000)
cv2.destroyAllWindows()