# import glove sensor data from CSV files
from __future__ import print_function
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import h5py

g_data_8 = np.genfromtxt("./data/feature8.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_like = np.genfromtxt("./data/featurelike.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_ok = np.genfromtxt("./data/featureok.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_rock = np.genfromtxt("./data/featurerock.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_scissor = np.genfromtxt("./data/featurescissor.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_start = np.genfromtxt("./data/featurestart.csv", dtype=np.float, delimiter=",")[1:][:]
g_data_thumb = np.genfromtxt("./data/featurethumb.csv", dtype=np.float, delimiter=",")[1:][:]


# merge all to g_data
g_data = np.append(g_data_8, g_data_like, axis=0)
g_data = np.append(g_data, g_data_ok, axis=0)
g_data = np.append(g_data, g_data_rock, axis=0)
g_data = np.append(g_data, g_data_scissor, axis=0)
g_data = np.append(g_data, g_data_start, axis=0)
g_data = np.append(g_data, g_data_thumb, axis=0)

# select features
############## Single Finger ###################
# # P
# col = np.array([0, 1, 2, 3, 4])
# # PV
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15])
# # PVA
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 18, 19, 20, 21, 22, 23])

############## Adjacent Finger ###################
# # P
# col = np.array([0, 1, 2, 3, 4, 24, 25, 26, 27])
# # PV
col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 24, 25, 26, 27, 28, 29, 30, 31])
# # PVA
# col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])

g_data = g_data[:, col]

# create arrays for labels
g_label_8 = np.tile([1, 0, 0, 0, 0, 0, 0], (g_data_8.shape[0], 1))
g_label_like = np.tile([0, 1, 0, 0, 0, 0, 0], (g_data_like.shape[0], 1))
g_label_ok = np.tile([0, 0, 1, 0, 0, 0, 0], (g_data_ok.shape[0], 1))
g_label_rock = np.tile([0, 0, 0, 1, 0, 0, 0], (g_data_rock.shape[0], 1))
g_label_scissor = np.tile([0, 0, 0, 0, 1, 0, 0], (g_data_scissor.shape[0], 1))
g_label_start = np.tile([0, 0, 0, 0, 0, 1, 0], (g_data_start.shape[0], 1))
g_label_thumb = np.tile([0, 0, 0, 0, 0, 0, 1], (g_data_thumb.shape[0], 1))

g_label = np.append(g_label_8, g_label_like, axis=0)
g_label = np.append(g_label, g_label_ok, axis=0)
g_label = np.append(g_label, g_label_rock, axis=0)
g_label = np.append(g_label, g_label_scissor, axis=0)
g_label = np.append(g_label, g_label_start, axis=0)
g_label = np.append(g_label, g_label_thumb, axis=0)

# Standardize data
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
g_data = scaler.fit_transform(g_data)

# create train and test sets
train_indices = np.random.choice(g_data.shape[0], int(0.8*g_data.shape[0]), replace=False)
test_indices = np.array(list(set(range(g_data.shape[0])) - set(train_indices)))
x_vals_train = g_data[train_indices]
x_vals_test = g_data[test_indices]
y_vals_train = g_label[train_indices]
y_vals_test = g_label[test_indices]

# Plot the data
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
# fig = plt.figure()
# ax = Axes3D(fig)
# ax.scatter(g_data[:,0], g_data[:,1], g_data[:,2], c=g_label)
# plt.show()

# define the model
def init_weight(shape, st_dev):
    weight = tf.Variable(tf.random_normal(shape, stddev=st_dev))
    return(weight)

def init_bias(shape, st_dev):
    bias = tf.Variable(tf.random_normal(shape, stddev=st_dev))
    return(bias)

x_data = tf.placeholder(shape=[None, g_data.shape[1]], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, g_label.shape[1]], dtype=tf.float32)

learning_rate = tf.placeholder(dtype=tf.float32)

def fully_connected(input_layer, weights, biases):
    layer = tf.add(tf.matmul(input_layer, weights), biases)
    return(tf.nn.relu(layer))

# MLP Structure
InputLayer = g_data.shape[1]
HiddenLayer = [25, 50, 30]
Output_Layer = g_label.shape[1]

# create hidden layer
weight_1 = init_weight(shape=[InputLayer, HiddenLayer[0]], st_dev=1.0)
bias_1 = init_bias(shape=[HiddenLayer[0]], st_dev=1)
layer_1 = fully_connected(x_data, weight_1, bias_1)

weight_2 = init_weight(shape=[HiddenLayer[0], HiddenLayer[1]], st_dev=1.0)
bias_2 = init_bias(shape=[HiddenLayer[1]], st_dev=1.0)
layer_2 = fully_connected(layer_1, weight_2, bias_2)

weight_3 = init_weight(shape=[HiddenLayer[1], HiddenLayer[2]], st_dev=1.0)
bias_3 = init_bias(shape=[HiddenLayer[2]], st_dev=1.0)
layer_3 = fully_connected(layer_2, weight_3, bias_3)

# create output layer
weight_4 = init_weight(shape=[HiddenLayer[2], Output_Layer], st_dev=1.0)
bias_4 = init_bias(shape=[Output_Layer], st_dev=1.0)
final_output = tf.matmul(layer_3, weight_4) + bias_4
# final_output = fully_connected(layer_3, weight_4, bias_4)
# final_output = tf.nn.softmax(tf.matmul(layer_3, weight_4) + bias_4)

# Get the train accuracy
temp_prediction = tf.equal(tf.argmax(y_target, 1), tf.argmax(tf.nn.softmax(final_output), 1))
# temp_prediction = tf.equal(tf.argmax(y_target, 1), tf.argmax(final_output, 1))
accuracy = tf.reduce_mean(tf.cast(temp_prediction, tf.float32))

# define the loss
loss = tf.losses.softmax_cross_entropy(onehot_labels=y_target, logits=final_output)

# define an optimizer
optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate).minimize(loss)

# Create a Session
config = tf.ConfigProto()
config.gpu_options.allow_growth =True
sess = tf.Session(config=config)
#sess = tf.Session()

# init the variables
initializer = tf.global_variables_initializer()
sess.run(initializer)

# Train the model
train_loss_vec = []
test_loss_vec = []
train_accuracy_vec = []
test_accuracy_vec = []
batch_size = 100
for i in range(100000):
    # choose random indices for batch selection
    rand_index = np.random.choice(x_vals_train.shape[0], size=batch_size)
    # Get random batch
    rand_x = x_vals_train[rand_index]
    rand_y = y_vals_train[rand_index] # attention
    # Learning rate control
    rate = 0.01
    if i > 5000 and i < 30000:
        rate = 0.007
    elif i >=30000:
        rate = 0.0001

    # Run the training step
    sess.run(optimizer, feed_dict={x_data: rand_x, y_target: rand_y, learning_rate: rate})

    if (i+1)%500 == 0:
        # Get and store the train loss
        temp_train_loss = sess.run(loss, feed_dict={x_data: rand_x, y_target: rand_y})
        train_loss_vec.append(float(temp_train_loss))
        # Get and store the test loss
        temp_test_loss = sess.run(loss, feed_dict={x_data: x_vals_test, y_target: y_vals_test})
        train_loss_vec.append(float(temp_test_loss))

        # Get and store train accuracy
        temp_train_accuracy = sess.run(accuracy, feed_dict={x_data: rand_x, y_target: rand_y})
        train_accuracy_vec.append(float(temp_train_accuracy))

        # Get and store test accuracy
        temp_test_accuracy = sess.run(accuracy, feed_dict={x_data: x_vals_test, y_target: y_vals_test})
        test_accuracy_vec.append(float(temp_test_accuracy))

        print('Generation: ' + str(i+1) + '. Learning rate = ' + str(rate) + '. Loss = ' + str(temp_train_loss))
        print('Generation: ' + str(i + 1) + '. Train Accuracy = ' + str(temp_train_accuracy)+ '. Test Accuracy = ' + str(temp_test_accuracy))

# Get and save the model parameter
# file = h5py.File('MLP16_model.h5', 'w')
file = h5py.File('MLP_model_PV.h5', 'w')

file.create_dataset('weight_1', data=sess.run(weight_1))
file.create_dataset('bias_1', data=sess.run(bias_1))
file.create_dataset('weight_2', data=sess.run(weight_2))
file.create_dataset('bias_2', data=sess.run(bias_2))
file.create_dataset('weight_3', data=sess.run(weight_3))
file.create_dataset('bias_3', data=sess.run(bias_3))
file.create_dataset('weight_4', data=sess.run(weight_4))
file.create_dataset('bias_4', data=sess.run(bias_4))

file.create_dataset('scaler_data_max', data=scaler.data_max_)
file.create_dataset('scaler_data_min', data=scaler.data_min_)
file.create_dataset('scaler_data_scaler', data=scaler.scale_)

file.close()

# sess.run(tf.argmax(final_output, 1), feed_dict={x_data: g_data[0:1450]})

plt.plot(train_loss_vec, 'k-', label='Train Loss')
plt.plot(test_loss_vec, 'r-', label='Test Loss')
plt.title('Loss per Generation')
plt.xlabel('Generation')
plt.ylabel('Loss')
plt.legend(loc='upper right')
plt.show()

plt.plot(train_accuracy_vec, 'k-', label='Train Accuracy')
plt.plot(test_accuracy_vec, 'r-', label='Test Accuracy')
plt.title('Accuracy per Generation')
plt.xlabel('Generation')
plt.ylabel('Accuracy')
plt.legend(loc='upper right')
plt.show()

