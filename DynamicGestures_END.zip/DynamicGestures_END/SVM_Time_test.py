import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.externals import joblib
import time

rbf_kernal_ovr_save = joblib.load('rbf_kernal_ovr.pkl')
rbf_kernal_ovo_save = joblib.load('rbf_kernal_ovo.pkl')
ploy_kernal_ovr_save = joblib.load('ploy_kernal_ovr.pkl')
ploy_kernal_ovo_save = joblib.load('ploy_kernal_ovo.pkl')
# 1-0  3-1  4-2  6-3  7-4  8-5 bishi-6 G3-7
input = np.genfromtxt("./data/feature8.csv", dtype=np.float, delimiter=",")[1:][:]
col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 24, 25, 26, 27, 28, 29, 30, 31])
input = input[:, col]

start = time.time()
Gesture_kind = ploy_kernal_ovr_save.predict(input)
accuracy = (Gesture_kind.tolist().count(0))*1.0/len(Gesture_kind)
print('accuracy is: ' + str(accuracy))
print(Gesture_kind)
print(input.shape[0])
print(time.time()-start)