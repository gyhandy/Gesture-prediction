import numpy as np
import tensorflow as tf
import h5py
import time

file = h5py.File('MLP3_model_PV.h5', 'r')
#
input = np.genfromtxt("./data/feature8.csv", dtype=np.float, delimiter=",")[1:][:]
col = np.array([0, 1, 2, 3, 4, 7, 9, 11, 13, 15, 24, 25, 26, 27, 28, 29, 30, 31])
input = input[:, col]

scaler_data_max = file['scaler_data_max']
scaler_data_min = file['scaler_data_min']
scaler_data_scaler = file['scaler_data_scaler']

input = (input - scaler_data_min) * scaler_data_scaler

x_data = tf.placeholder(shape=[None, input.shape[1]], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, 6], dtype=tf.float32)


def fully_connected(input_layer, weights, biases):
    layer = tf.add(tf.matmul(input_layer, weights), biases)
    return(tf.nn.relu(layer))


# create hidden layer
weight_1 = file['weight_1'][:]
bias_1 = file['bias_1'][:]
layer_1 = fully_connected(x_data, weight_1, bias_1)

weight_2 = file['weight_2'][:]
bias_2 = file['bias_2'][:]
layer_2 = fully_connected(layer_1, weight_2, bias_2)

# create output layer
weight_3 = file['weight_3'][:]
bias_3 = file['bias_3'][:]
final_output = tf.matmul(layer_2, weight_3) + bias_3
predict = tf.argmax(final_output, 1)

# Create a Session
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)
#sess = tf.Session()
start = time.time()

Gesture_kind = sess.run(predict, feed_dict={x_data: input})
accuracy = (Gesture_kind.tolist().count(1))*1.0/len(Gesture_kind)
print('accuracy is: ' + str(accuracy))
print(Gesture_kind)
print(input.shape[0])
print(time.time()-start)
