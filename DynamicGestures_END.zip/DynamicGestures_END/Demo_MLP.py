# -*- coding:utf-8 -*-
import time
import numpy as np
import serial
import tensorflow as tf
import h5py
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import cv2

plt.ion()

file = h5py.File('MLP_model.h5', 'r')

scaler_data_max = file['scaler_data_max']
scaler_data_min = file['scaler_data_min']
scaler_data_scaler = file['scaler_data_scaler']

# x_data = tf.placeholder(shape=[None, 12], dtype=tf.float32)
# y_target = tf.placeholder(shape=[None, 16], dtype=tf.float32)
x_data = tf.placeholder(shape=[None, 10], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, 7], dtype=tf.float32)

def fully_connected(input_layer, weights, biases):
    layer = tf.add(tf.matmul(input_layer, weights), biases)
    return(tf.nn.relu(layer))

def print_once(dict, new_state, pre_state):
    if new_state != pre_state:
        print(dict[new_state])

# create hidden layer
weight_1 = file['weight_1'][:]
bias_1 = file['bias_1'][:]
layer_1 = fully_connected(x_data, weight_1, bias_1)

weight_2 = file['weight_2'][:]
bias_2 = file['bias_2'][:]
layer_2 = fully_connected(layer_1, weight_2, bias_2)

weight_3 = file['weight_3'][:]
bias_3 = file['bias_3'][:]
layer_3 = fully_connected(layer_2, weight_3, bias_3)

# create output layer
weight_4 = file['weight_4'][:]
bias_4 = file['bias_4'][:]
final_output = tf.matmul(layer_3, weight_4) + bias_4

predict = tf.argmax(final_output, 1)

# Create a Session
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)

gesturedict = {0: '8', 1: 'like', 2: 'ok', 3: 'rock', 4: 'scissor', 5: 'start', 6: 'thumb'}

data = np.zeros([17, 18])
num_data = 0
index = 0
n = 5  # number of data to define the gesture

ser = serial.Serial( #下面这些参数根据情况修改
    port='/dev/ttyACM1',
    baudrate=38400,
    parity=serial.PARITY_ODD,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS
)

time.sleep(0.5)
steady_state = np.zeros((25,1)); steady_state_index = 0; prestate = 0
# keepstate = np.zeros((2,1));stateindex = 0;switch_flag = 0;tmp_output = 0;tmp_flag = 0
pred_flag = False; Mid_Pre_gesture=[]; start_time = 0; predict_time =0; tank_lenth = 10;start_flag = False
while True:
    while ser.inWaiting() > 0:
        try:
            a = str(ser.readline()).strip()
            b = a.split(',')
            assert len(b) == 6
            data[index, 0] = b[0]
            data[index, 1] = b[1]
            data[index, 2] = b[2]
            data[index, 3] = b[3]
            data[index, 4] = b[4]
            data[index, 5] = b[5]
            # print(a)
            if num_data >= 6:
                cur_index = num_data % 17
                data[cur_index - 3][6] = (data[cur_index][0] - data[cur_index - 6][0])/6.0
                data[cur_index - 3][8] = (data[cur_index][1] - data[cur_index - 6][1])/6.0
                data[cur_index - 3][10] = (data[cur_index][2] - data[cur_index - 6][2])/6.0
                data[cur_index - 3][12] = (data[cur_index][3] - data[cur_index - 6][3])/6.0
                data[cur_index - 3][14] = (data[cur_index][4] - data[cur_index - 6][4])/6.0
                data[cur_index - 3][16] = (data[cur_index][5] - data[cur_index - 6][5])/6.0

            if num_data >= 16:
                cur_index = num_data % 17
                if cur_index - 8 - 5 >= -11 and cur_index - 8 - 5 <= -1:
                    matrix = np.concatenate((data[cur_index - 8 - 5:, :], data[:cur_index - 8 + 5 + 1, :]))
                    data[cur_index - 8][7] = np.sum(matrix[:, 6]) / 11.0
                    data[cur_index - 8][9] = np.sum(matrix[:, 8]) / 11.0
                    data[cur_index - 8][11] = np.sum(matrix[:, 10]) / 11.0
                    data[cur_index - 8][13] = np.sum(matrix[:, 12]) / 11.0
                    data[cur_index - 8][15] = np.sum(matrix[:, 14]) / 11.0
                    data[cur_index - 8][17] = np.sum(matrix[:, 16]) / 11.0
                else:
                    matrix = data[cur_index - 8 - 5:cur_index - 8 + 5 + 1, :]
                    data[cur_index - 8][7] = np.sum(matrix[:, 6]) / 11.0
                    data[cur_index - 8][9] = np.sum(matrix[:, 8]) / 11.0
                    data[cur_index - 8][11] = np.sum(matrix[:, 10]) / 11.0
                    data[cur_index - 8][13] = np.sum(matrix[:, 12]) / 11.0
                    data[cur_index - 8][15] = np.sum(matrix[:, 14]) / 11.0
                    data[cur_index - 8][17] = np.sum(matrix[:, 16]) / 11.0

            # detect the gesture every n samples
            if num_data >= 20:
                cur_index = (num_data - 20 + 8) % 17
                col = np.array([0, 1, 2, 3, 4, 5, 7, 9, 11, 13, 15, 17])
                if cur_index + n > 17:
                    # input_MutiLayer = 1
                    new_index = (cur_index + n) % 16
                    input_MutiLayer = np.concatenate((data[cur_index:, col], data[:new_index - 1, col]))
                else:
                    input_MutiLayer = data[cur_index:cur_index + n, col]

                # detect the input
                # scale
                input_MutiLayer = np.append(input_MutiLayer[:, 0:5], input_MutiLayer[:, 6:11], axis=1)
                input_MutiLayer = (input_MutiLayer - scaler_data_min) * scaler_data_scaler
                Gesture_kind = sess.run(predict, feed_dict={x_data: input_MutiLayer})

                tu = sorted([(np.sum(Gesture_kind == i), i) for i in set(Gesture_kind.flat)])
                output = tu[-1][1]

                ###########################################################
                # if tmp_output == output and tmp_flag == 0:
                #     s_time = time.time()
                #     tmp_flag = 1
                # if tmp_flag == 1:
                #     if tmp_output == output:
                #         if time.time() - s_time > 0.05:
                #             tmp_flag = 0
                #             # print(output)
                #             keepstate[stateindex] = output
                #             stateindex = (stateindex + 1) % 2
                #     else:
                #         tmp_output = output
                #
                # if keepstate[0] != keepstate[1]:
                #     time_start = time.time()
                #     switch_flag = 1
                # if switch_flag == 1:
                #     if keepstate[0] == keepstate[1]:
                #         time_end = time.time()
                #         if time_end - time_start > 0.1:
                #             print(gesturedict[output])
                #             switch_flag = 0
                # tmp_output = output
                #
                #####################################################
                # steady_state[steady_state_index] = output
                # uu = sorted([(np.sum(steady_state == i), i) for i in set(steady_state.flat)])
                # if uu[-1][0] >= 0.9 * steady_state.shape[0]:
                #     newstate = int(uu[-1][1])
                #
                #     print_once(gesturedict, newstate, prestate)
                #     prestate = newstate
                #     # print(gesturedict[newstate])
                #
                # steady_state_index = (steady_state_index + 1) % steady_state.shape[0]
                #####################################################
                Mid_Pre_gesture.append(output)
                if len(Mid_Pre_gesture) >= tank_lenth:
                    mid = sorted([(np.sum(Gesture_kind == i), i) for i in set(Gesture_kind.flat)])
                    tank_output = mid[-1][1]
                    if tank_output == 5:
                        predict_time = 0
                        last_out = tank_output
                        if start_time >= 10:  # 判断初始位置所需的时间 5
                            print('Start predicting')
                            if start_flag == False:
                                # start_img = cv2.imread('start.png')
                                # win = cv2.namedWindow('test win')
                                plt.figure(1)
                                start_img = mpimg.imread('start.png')
                                plt.imshow(start_img)
                                plt.draw()
                                # cv2.imshow('test', start_img)
                                # cv2.waitKey()
                                start_flag = True
                            pred_flag = True
                            start_time = 0
                        else:
                            start_time += 1
                    else:
                        start_flag = False
                        start_time = 0
                        if pred_flag == True:
                            if predict_time >= 9:  # 正确预测所需的时间 2
                                print(str(tank_output) + '   ' + gesturedict[tank_output])
                                # plt.cla()
                                # cv2.destroyAllWindows()
                                plt.close('all')
                                pic_name = gesturedict[tank_output] + '.png'
                                # gesture_img = cv2.imread(pic_name)
                                # cv2.imshow('predict', pic_name)
                                # cv2.waitKey(0)
                                # plt.figure(2)
                                gesture_img = mpimg.imread(pic_name)
                                plt.imshow(gesture_img)
                                plt.draw()
                                pred_flag = False
                            else:
                                if tank_output == last_out:
                                    predict_time += 1
                                else:
                                    predict_time = 0
                                last_out = tank_output  # 记录上次状态
                                tank_output = 0
                        else:
                            Mid_Pre_gesture = []
                #####################################################
                # keepstate[stateindex] = output
                # if keepstate[0] != keepstate[1]:
                #     time_start = time.time()
                #     switch_flag = 1
                # if switch_flag == 1:
                #     if keepstate[0] == keepstate[1]:
                #         time_end = time.time()
                #         if time_end - time_start > 0.2:
                #             print(gesturedict[output])
                #             switch_flag = 0
                #
                # print(str(Gesture_kind)+'   '+str(output)+'   ' + gesturedict[output])
                # # print(gesturedict[output])
                ####################################################

            index = (index + 1) % 17
            # stateindex = (stateindex + 1) % 2
            num_data += 1
        except AssertionError:
            print('AssertionError')
        except ValueError:
            print('ValueError')

